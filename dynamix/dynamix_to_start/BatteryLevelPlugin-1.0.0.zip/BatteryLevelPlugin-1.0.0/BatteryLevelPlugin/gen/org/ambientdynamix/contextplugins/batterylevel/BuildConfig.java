/** Automatically generated file. DO NOT MODIFY */
package org.ambientdynamix.contextplugins.batterylevel;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}