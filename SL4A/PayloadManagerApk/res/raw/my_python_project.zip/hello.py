import android, time

droid = android.Android()

droid.makeToast("Hello happy android...")
